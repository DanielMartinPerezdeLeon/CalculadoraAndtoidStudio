package com.example.calculadorapmdm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.security.Principal;

public class MainActivity extends AppCompatActivity {

    Button btn_0 = (Button) findViewById(R.id.btn_0);
    TextView txtprincipal = (TextView) findViewById(R.id.Principal);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }


}